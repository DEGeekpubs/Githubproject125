﻿<html>
<body>

<head>
<meta http-equiv="content-type" content="text/html; charset=utf-8" />
<title>PHILIPPNE POSTAL CORPORATION</title>
<meta name="keywords" content="" />
<meta name="description" content="" />
<link href="style.css" rel="stylesheet" type="text/css" media="screen" />
<link href="style/calendar.css" rel="stylesheet" type="text/css" media="screen"/>
<script type="text/javascript" src="script/calendar.js"></script>

<div id="header">
	<BR><BR>
	<center><b><font color="Sienna" size="4"  FONT FACE=andalus>PHILIPPINE POSTAL CORPORATION TRACKING SYSYEM</font></b></center>
</head>
</div>

<div id="menu">
	<ul>
		<li class="first"><a href="home.php">HOME</a></li>
		<li><a href="#">ABOUT US</a></li>
		<li><a href="corporate.php">CORPORATE</a></li>
		<li><a href="delivery.php">DELIVERY RATES</a></li>
		<li><a href="news.php">NEWS</a></li>
		<li><a href="operations.php">OPERATIONS</a></li>
	</ul>
</div>
<div id="page">
	<div id="page-top">
		<div id="page-bottom">
		<div>
			<div id="sidebar">
		
				SAYYED-ALI B. ABDULLAH
				
		        


			
		<img src="mainpic.jpg" width="750" name="dob" onclick="displayDatePicker('dob');" class="text">



			
		</div>
		<div style="clear: both;">&nbsp;</div>
	</div>
	</div>
</div>
</div>
<div id="footer">
	<b><p>Copyright © 2009  PhilPostCorp.freehostia.com. Created by Ekis Boys</p></b>
</div>
</body>
</html>
