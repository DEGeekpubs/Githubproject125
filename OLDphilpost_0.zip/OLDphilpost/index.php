<?
?>

<html>
 <head>
  <title>Region 12-Philippine Postal Corporation</title>
  <meta name="Author" CONTENT="Triple W Communications">
 <link rel="stylesheet" type="text/css" href="style_sheet_1.css" title="wak" />  </head>

 <center><img src="philpostLOGO.png" >&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</center>
 <br>
 <body bgcolor="#E7ECFD  ">
  <center>
   <object classid="clsid:D27CDB6E-AE6D-11cf-96B8-444553540000" codebase="http://download.macromedia.com/pub/shockwave/cabs/flash/swflash.cab#5,0,0,0" width="600" height="300">
    <param name="SRC" value="gforward.swf">
    <embed src="gforward.swf" pluginspage="http://www.macromedia.com/shockwave/download/" type="application/x-shockwave-flash" width="600" height="300">
    </embed>
   </object>
   <br><br>																																													
   
   <tr><td></td><td><b><input type=submit  border=0 value="CLICK HERE TO ENTER" style="background-color:Spring;height:20;width:160;color:Red;"ONMOUSEOVER="this.style.border='5px solid #87CEEB'"ONMOUSEOUT="this.style.border='2px solid #708090'" ONCLICK="window.location.href='./home.php'></b></td></tr>
  </center>


 </body>
</html>