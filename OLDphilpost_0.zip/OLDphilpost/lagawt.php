<?php

session_start(); ?>

<html>
<head>


<meta http-equiv="content-type" content="text/html; charset=utf-8" />
<title>OPERATIONS</title>
<meta name="keywords" content="" />
<meta name="description" content="" />
<link href="style.css" rel="stylesheet" type="text/css" media="screen" /> 
</head>

<body>
<div id="header">
   <!--DHODSKi_bOi-->
</div>
<div id="menu">
	<center><ul>
		<li class="first"><a href="home.php">HOME</a></li>
		<li><a href="#">ABOUT US</a></li>
		<li><a href="delivery.php">DELIVERY RATES</a></li>
		<li><a href="news.php">NEWS</a></li>
		<li><a href="operations.php">OPERATIONS</a></li>
	</ul></center>
</div>
<div id="page">
	<div style='background-color:WHITE'>
	<br>
	
	<? session_start();
	   session_destroy(); 

		?>
		<script>setTimeout("location.href='./corporate.php'",0);</script> 
	
 		
		
		
	
	  <br><br><center><button type="submit" style="width:200;background-color:SpringGreen;">SUBMIT</button></center>
</table>
</form>

<br><br><br>

	</div>
  </div>
</div>


	<center>
	 <div id="footer">
	<b><p>Copyright � 2009  PhilPostCorp.freehostia.com Created by Ekis Boys</p></b>
	</div>
	</center>
	
 
 


</body>
</html>